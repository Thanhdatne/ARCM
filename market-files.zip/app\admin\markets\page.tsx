"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import {
  MARKET_TEMPLATES,
  type MarketTemplateCategory,
} from "@/lib/marketTemplates";
import { CheckCircle2, KeyRound, Layers3, RefreshCw, Search, ShieldCheck, Trophy } from "lucide-react";


type OutcomeType = "home_win" | "draw" | "away_win";
type MarketTemplate = (typeof MARKET_TEMPLATES)[number];
type AdminCatalogCategory = MarketTemplateCategory | "World Cup";

type TemplateDeployState =
  | { status: "idle" }
  | { status: "deploying" }
  | {
      status: "success";
      marketAddress: string;
      ammAddress: string;
      transactionHash?: string;
      collateralSymbol?: string;
      collateralDecimals?: number;
      contractVersion?: number;
    }
  | { status: "error"; message: string };

interface CreateMarketV2Response {
  success?: boolean;
  error?: string;
  market?: {
    marketAddress?: string;
    address?: string;
    ammAddress?: string;
    transactionHash?: string;
    txHash?: string;
    collateralSymbol?: string;
    collateralDecimals?: number;
    contractVersion?: number;
  };
  transactionHash?: string;
  txHash?: string;
}

interface WorldCupResultRecord {
  fixtureId: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number | null;
  awayScore: number | null;
  status: "pending" | "final" | "postponed" | "cancelled";
  result?: OutcomeType | null;
  updatedAt: string;
  source?: string;
  kickoffTime?: string;
  startsAt?: string;
  startTime?: string;
  scheduledAt?: string;
  updateAllowedAt?: string;
}

interface RoundOf32Market {
  id: string;
  address?: string;
  marketAddress?: string;
  ammAddress?: string;
  title: string;
  category: string;
  homeTeam?: string;
  awayTeam?: string;
  stage?: string;
  kickoffTime?: string;
  contractVersion?: number;
  finalHomeScore?: number;
  finalAwayScore?: number;
  winningSide?: "YES" | "NO";
  winningTeam?: string;
  resultSource?: string;
  resultUpdatedAt?: string;
  resultStatus?: "saved" | "proposed" | "settled";
}

interface ResultFormState {
  homeScore: string;
  awayScore: string;
  winningSide: "YES" | "NO";
  resultSource: string;
  status?: "idle" | "saving" | "success" | "error";
  message?: string;
}

interface WorldCupDeployment {
  worldCupMarketId?: string;
  fixtureId: string;
  group?: string;
  question: string;
  outcomeType: OutcomeType | string;
  marketAddress: string;
  ammAddress?: string;
  contractVersion?: number;
  collateralSymbol?: string;
  createdAt?: string;
  isRoundOf32V2?: boolean;
}

interface ResolverItem {
  fixtureId: string;
  outcomeType: string;
  question: string;
  proposedSide?: "YES" | "NO";
  action:
    | "prepared"
    | "proposed"
    | "oracleSettled"
    | "marketSettled"
    | "readyForClaim"
    | "timerAdvanced"
    | "settled"
    | "skipped"
    | "failed";
  reason: string;
  state?: number;
  txHash?: string;
}

interface ResolverResponse {
  success?: boolean;
  error?: string;
  action?: string;
  fixtureId?: string;
  scanned?: number;
  proposed?: number;
  timerAdvanced?: number;
  settled?: number;
  skipped?: number;
  failed?: number;
  items?: ResolverItem[];
}

interface FixtureResolverStatus {
  fixtureId: string;
  status:
    | "notDeployed"
    | "needsResolve"
    | "waiting"
    | "readyToSettle"
    | "settled"
    | "partial"
    | "oracleSettled"
    | "unknown";
  reason: string;
  marketsTotal: number;
  needsResolve: number;
  waiting: number;
  readyToSettle: number;
  settled: number;
  oracleSettled: number;
  failed: number;
  fastSettleAvailable?: boolean;
}

const adminMarketCreateEnabled =
  process.env.NEXT_PUBLIC_ENABLE_ADMIN_MARKET_CREATE === "true";

const ARC_NATIVE_USDC_ADDRESS = "0x3600000000000000000000000000000000000000";

const categories: ("All" | AdminCatalogCategory)[] = [
  "All",
  "World Cup",
  "Arc",
  "Crypto",
  "Stablecoins",
  "AI",
  "Macro",
  "RWA",
  "Privacy",
];

const categoryCopy: Record<AdminCatalogCategory, { label: string; icon: string; description: string }> = {
  "World Cup": {
    label: "World Cup",
    icon: "WC",
    description: "Binary knockout markets.",
  },
  Arc: {
    label: "Arc",
    icon: "ARC",
    description: "Arc Testnet ecosystem and builder markets.",
  },
  Crypto: {
    label: "Crypto",
    icon: "BTC",
    description: "Token price and crypto market structure.",
  },
  Stablecoins: {
    label: "Stablecoins",
    icon: "USDC",
    description: "Peg, supply, and stablecoin infrastructure.",
  },
  AI: {
    label: "AI",
    icon: "AI",
    description: "Models, agents, GPUs, and AI product launches.",
  },
  Macro: {
    label: "Macro",
    icon: "MAC",
    description: "Rates, CPI, unemployment, and macro events.",
  },
  RWA: {
    label: "RWA",
    icon: "RWA",
    description: "Tokenized assets, treasuries, and onchain finance.",
  },
  Privacy: {
    label: "Privacy",
    icon: "ZK",
    description: "ZK, shielded positions, and privacy demos.",
  },
};

const WORLD_CUP_FIXTURE_DATE_BY_ID: Record<string, string> = {
  "group-a-mexico-vs-south-africa": "2026-06-11",
  "group-a-south-korea-vs-czechia": "2026-06-11",
  "group-b-canada-vs-bosnia-and-herzegovina": "2026-06-12",
  "group-d-united-states-vs-paraguay": "2026-06-12",
  "group-b-qatar-vs-switzerland": "2026-06-13",
  "group-c-brazil-vs-morocco": "2026-06-13",
  "group-c-haiti-vs-scotland": "2026-06-13",
  "group-d-australia-vs-turkey": "2026-06-14",
  "group-e-germany-vs-curacao": "2026-06-14",
  "group-f-netherlands-vs-japan": "2026-06-14",
  "group-e-ivory-coast-vs-ecuador": "2026-06-14",
  "group-f-sweden-vs-tunisia": "2026-06-14",
  "group-h-spain-vs-cape-verde": "2026-06-15",
  "group-g-belgium-vs-egypt": "2026-06-15",
  "group-h-saudi-arabia-vs-uruguay": "2026-06-15",
  "group-g-iran-vs-new-zealand": "2026-06-15",
  "group-i-france-vs-senegal": "2026-06-16",
  "group-i-iraq-vs-norway": "2026-06-16",
  "group-j-argentina-vs-algeria": "2026-06-16",
  "group-j-austria-vs-jordan": "2026-06-17",
  "group-k-portugal-vs-dr-congo": "2026-06-17",
  "group-l-england-vs-croatia": "2026-06-17",
  "group-l-ghana-vs-panama": "2026-06-17",
  "group-k-uzbekistan-vs-colombia": "2026-06-17",
  "group-a-czechia-vs-south-africa": "2026-06-18",
  "group-b-switzerland-vs-bosnia-and-herzegovina": "2026-06-18",
  "group-b-canada-vs-qatar": "2026-06-18",
  "group-a-mexico-vs-south-korea": "2026-06-18",
  "group-d-united-states-vs-australia": "2026-06-19",
  "group-c-scotland-vs-morocco": "2026-06-19",
  "group-c-brazil-vs-haiti": "2026-06-19",
  "group-d-turkey-vs-paraguay": "2026-06-19",
  "group-f-netherlands-vs-sweden": "2026-06-20",
  "group-e-germany-vs-ivory-coast": "2026-06-20",
  "group-e-ecuador-vs-curacao": "2026-06-20",
  "group-f-tunisia-vs-japan": "2026-06-21",
  "group-h-spain-vs-saudi-arabia": "2026-06-21",
  "group-g-belgium-vs-iran": "2026-06-21",
  "group-h-uruguay-vs-cape-verde": "2026-06-21",
  "group-g-new-zealand-vs-egypt": "2026-06-21",
  "group-j-argentina-vs-austria": "2026-06-22",
  "group-i-france-vs-iraq": "2026-06-22",
  "group-i-norway-vs-senegal": "2026-06-22",
  "group-j-jordan-vs-algeria": "2026-06-22",
  "group-k-portugal-vs-uzbekistan": "2026-06-23",
  "group-l-england-vs-ghana": "2026-06-23",
  "group-l-panama-vs-croatia": "2026-06-23",
  "group-k-colombia-vs-dr-congo": "2026-06-23",
  "group-b-switzerland-vs-canada": "2026-06-24",
  "group-b-bosnia-and-herzegovina-vs-qatar": "2026-06-24",
  "group-c-scotland-vs-brazil": "2026-06-24",
  "group-c-morocco-vs-haiti": "2026-06-24",
  "group-a-czechia-vs-mexico": "2026-06-24",
  "group-a-south-africa-vs-south-korea": "2026-06-24",
  "group-e-ecuador-vs-germany": "2026-06-25",
  "group-e-curacao-vs-ivory-coast": "2026-06-25",
  "group-f-tunisia-vs-netherlands": "2026-06-25",
  "group-f-japan-vs-sweden": "2026-06-25",
  "group-d-turkey-vs-united-states": "2026-06-25",
  "group-d-paraguay-vs-australia": "2026-06-25",
  "group-i-norway-vs-france": "2026-06-26",
  "group-i-senegal-vs-iraq": "2026-06-26",
  "group-h-uruguay-vs-spain": "2026-06-26",
  "group-h-cape-verde-vs-saudi-arabia": "2026-06-26",
  "group-g-new-zealand-vs-belgium": "2026-06-26",
  "group-g-egypt-vs-iran": "2026-06-26",
  "group-l-panama-vs-england": "2026-06-27",
  "group-l-croatia-vs-ghana": "2026-06-27",
  "group-k-colombia-vs-portugal": "2026-06-27",
  "group-k-dr-congo-vs-uzbekistan": "2026-06-27",
  "group-j-jordan-vs-argentina": "2026-06-27",
  "group-j-algeria-vs-austria": "2026-06-27",
};

export default function AdminMarketsPage() {
  const [activeCategory, setActiveCategory] =
    useState<"All" | AdminCatalogCategory>("All");
  const [query, setQuery] = useState("");
  const [adminKey, setAdminKey] = useState("");
  const [saved, setSaved] = useState(false);
  const [worldCupResults, setWorldCupResults] = useState<WorldCupResultRecord[]>([]);
  const [worldCupDeployments, setWorldCupDeployments] = useState<WorldCupDeployment[]>([]);
  const [roundOf32Markets, setRoundOf32Markets] = useState<RoundOf32Market[]>([]);
  const [roundOf32Loading, setRoundOf32Loading] = useState(true);
  const [resultForms, setResultForms] = useState<Record<string, ResultFormState>>({});
  const [resultsLoading, setResultsLoading] = useState(true);
  const [deploymentsLoading, setDeploymentsLoading] = useState(true);
  const [resolverBusy, setResolverBusy] = useState("");
  const [resolverError, setResolverError] = useState("");
  const [resolverResponse, setResolverResponse] =
    useState<ResolverResponse | null>(null);
  const [resolverStatuses, setResolverStatuses] = useState<
    Record<string, FixtureResolverStatus>
  >({});
  const [statusesLoading, setStatusesLoading] = useState(true);
  const [templateDeployStates, setTemplateDeployStates] = useState<
    Record<string, TemplateDeployState>
  >({});
  const todayDateKey = useMemo(() => getLocalDateKey(new Date()), []);

  useEffect(() => {
    setAdminKey(window.localStorage.getItem("ARCM-admin-key") ?? "");
  }, []);

  const loadWorldCupResults = async () => {
    setResultsLoading(true);

    try {
      const response = await fetch("/api/world-cup/results", {
        cache: "no-store",
      });
      const data = (await response.json()) as
        | WorldCupResultRecord[]
        | Record<string, WorldCupResultRecord>;

      setWorldCupResults(Array.isArray(data) ? data : Object.values(data ?? {}));
    } catch {
      setWorldCupResults([]);
    } finally {
      setResultsLoading(false);
    }
  };

  const loadWorldCupDeployments = async () => {
    setDeploymentsLoading(true);

    try {
      const response = await fetch("/api/world-cup/deployments", {
        cache: "no-store",
      });
      const data = (await response.json()) as
        | WorldCupDeployment[]
        | {
            deployments?: WorldCupDeployment[];
            markets?: WorldCupDeployment[];
            data?: WorldCupDeployment[];
          }
        | Record<string, WorldCupDeployment>;

      const deployments = Array.isArray(data)
        ? data
        : Array.isArray(data.deployments)
          ? data.deployments
          : Array.isArray(data.markets)
            ? data.markets
            : Array.isArray(data.data)
              ? data.data
              : Object.values(data ?? {});

      setWorldCupDeployments(
        deployments.filter((deployment) => (
          Boolean(deployment.fixtureId) &&
          Boolean(deployment.marketAddress)
        )),
      );
    } catch {
      setWorldCupDeployments([]);
    } finally {
      setDeploymentsLoading(false);
    }
  };

  const loadRoundOf32Markets = async () => {
    setRoundOf32Loading(true);

    try {
      const response = await fetch("/api/markets", {
        cache: "no-store",
      });
      const data = (await response.json()) as RoundOf32Market[];
      const markets = Array.isArray(data) ? data : [];

      setRoundOf32Markets(
        markets.filter((market) => (
          market.category === "World Cup" &&
          isSupportedKnockoutStage(market.stage) &&
          Boolean(market.marketAddress || market.address) &&
          Boolean(market.ammAddress)
        )),
      );
    } catch {
      setRoundOf32Markets([]);
    } finally {
      setRoundOf32Loading(false);
    }
  };

  const loadResolverStatuses = async () => {
    setStatusesLoading(true);

    try {
      const response = await fetch("/api/world-cup/resolver-status", {
        cache: "no-store",
      });
      const data = (await response.json()) as {
        fixtures?: FixtureResolverStatus[];
      };
      const nextStatuses = Object.fromEntries(
        (data.fixtures ?? []).map((fixture) => [fixture.fixtureId, fixture]),
      );

      setResolverStatuses(nextStatuses);
    } catch {
      setResolverStatuses({});
    } finally {
      setStatusesLoading(false);
    }
  };

  useEffect(() => {
    void loadWorldCupResults();
    void loadWorldCupDeployments();
    void loadRoundOf32Markets();
    void loadResolverStatuses();
  }, []);

  const categoryCounts = useMemo(() => {
    return MARKET_TEMPLATES.reduce<Record<AdminCatalogCategory, number>>(
      (acc, template) => {
        acc[template.category as AdminCatalogCategory] += 1;
        return acc;
      },
      {
        "World Cup": 0,
        Arc: 0,
        Crypto: 0,
        Stablecoins: 0,
        AI: 0,
        Macro: 0,
        RWA: 0,
        Privacy: 0,
      },
    );
  }, []);

  const visibleTemplates = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return MARKET_TEMPLATES.filter((template) => {
      const categoryMatch =
        activeCategory === "All" || template.category === activeCategory;

      if (!categoryMatch) return false;
      if (!normalizedQuery) return true;

      return [
        template.title,
        template.category,
        template.source,
        template.settlementRule,
      ]
        .join(" ")
        .toLowerCase()
        .includes(normalizedQuery);
    });
  }, [activeCategory, query]);

  const deployedTemplateIds = useMemo(() => {
    const ids = new Set<string>();

    for (const deployment of worldCupDeployments) {
      if (deployment.worldCupMarketId) ids.add(deployment.worldCupMarketId);
    }

    for (const market of roundOf32Markets) {
      if (market.id) ids.add(market.id);
    }

    return ids;
  }, [roundOf32Markets, worldCupDeployments]);

  const saveAdminKey = () => {
    window.localStorage.setItem("ARCM-admin-key", adminKey.trim());
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1_500);
  };

  const deployTemplate = async (template: MarketTemplate) => {
    const key = adminKey.trim();

    if (!key) {
      setTemplateDeployStates((current) => ({
        ...current,
        [template.id]: { status: "error", message: "Paste ADMIN_API_KEY first." },
      }));
      return;
    }

    setTemplateDeployStates((current) => ({
      ...current,
      [template.id]: { status: "deploying" },
    }));

    try {
      const worldCupMarketId = getTemplateWorldCupMarketId(template);
      const response = await fetch("/api/create-market-v2", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-key": key,
        },
        body: JSON.stringify({
          title: template.title,
          category: template.category,
          pairName: stablePairName(template.id),
          collateralAddress: ARC_NATIVE_USDC_ADDRESS,
          proposerReward: "1",
          proposerBond: "1",
          initialLiquidity: "1",
          liveness: 7200,
          feeBps: 200,
          ...(worldCupMarketId ? { worldCupMarketId } : {}),
          ...(template.fixtureId ? { fixtureId: template.fixtureId } : {}),
          ...(template.group ? { group: template.group } : {}),
          ...(template.outcomeType ? { outcomeType: template.outcomeType } : {}),
          ...(template.homeTeam ? { homeTeam: template.homeTeam } : {}),
          ...(template.awayTeam ? { awayTeam: template.awayTeam } : {}),
          ...(template.stage ? { stage: template.stage } : {}),
          ...(template.kickoffTime ? { kickoffTime: template.kickoffTime } : {}),
          ...(template.homeCountryCode ? { homeCountryCode: template.homeCountryCode } : {}),
          ...(template.awayCountryCode ? { awayCountryCode: template.awayCountryCode } : {}),
        }),
      });

      const data = (await response.json().catch(() => ({}))) as CreateMarketV2Response;

      if (!response.ok) {
        throw new Error(data.error || "V2 USDC deployment failed.");
      }

      const marketAddress = data.market?.marketAddress ?? data.market?.address;
      if (!marketAddress) throw new Error("Deployment returned no market address.");
      const ammAddress = data.market?.ammAddress;
      if (!ammAddress) throw new Error("Deployment returned no AMM address.");

      setTemplateDeployStates((current) => ({
        ...current,
        [template.id]: {
          status: "success",
          marketAddress,
          ammAddress,
          transactionHash:
            data.market?.transactionHash ??
            data.market?.txHash ??
            data.transactionHash ??
            data.txHash,
          collateralSymbol: data.market?.collateralSymbol,
          collateralDecimals: data.market?.collateralDecimals,
          contractVersion: data.market?.contractVersion,
        },
      }));

      if (worldCupMarketId) {
        window.setTimeout(() => {
          void loadWorldCupDeployments();
        }, 1_500);
      }
    } catch (error) {
      setTemplateDeployStates((current) => ({
        ...current,
        [template.id]: {
          status: "error",
          message:
            error instanceof Error ? error.message : "V2 USDC deployment failed.",
        },
      }));
    }
  };

  const finalResults = useMemo(() => {
    return worldCupResults
      .filter((result) => result.status === "final" && result.result)
      .sort((a, b) => a.fixtureId.localeCompare(b.fixtureId));
  }, [worldCupResults]);

  const deployedFinalResults = useMemo(() => {
    return finalResults.filter((result) => (
      resolverStatuses[result.fixtureId]?.status !== "notDeployed"
    ));
  }, [finalResults, resolverStatuses]);

  const unresolvedDeployedFinalResults = useMemo(() => {
    return deployedFinalResults.filter((result) => (
      resolverStatuses[result.fixtureId]?.status !== "settled"
    ));
  }, [deployedFinalResults, resolverStatuses]);

  const visibleFinalResults = useMemo(() => {
    return unresolvedDeployedFinalResults.filter((result) => (
      isFixtureOnOrAfterDate(result, todayDateKey)
    ));
  }, [todayDateKey, unresolvedDeployedFinalResults]);

  const hiddenPastFixtureCount = unresolvedDeployedFinalResults.length - visibleFinalResults.length;

  const deploymentsByFixture = useMemo(() => {
    const grouped: Record<string, WorldCupDeployment[]> = {};
    const savedRoundOf32Deployments: WorldCupDeployment[] = roundOf32Markets
      .filter(isRoundOf32Market)
      .map((market) => ({
        worldCupMarketId: market.id,
        fixtureId: market.id,
        group: market.stage ?? "Knockout",
        question: market.title,
        outcomeType: "home_win",
        marketAddress: market.marketAddress ?? market.address ?? "",
        ammAddress: market.ammAddress,
        contractVersion: 2,
        collateralSymbol: "USDC",
        createdAt: undefined,
        isRoundOf32V2: true,
      }));

    for (const deployment of [...worldCupDeployments, ...savedRoundOf32Deployments]) {
      if (!deployment.fixtureId) continue;

      grouped[deployment.fixtureId] = [
        ...(grouped[deployment.fixtureId] ?? []),
        deployment,
      ];

      if (deployment.isRoundOf32V2) {
        for (const result of finalResults) {
          if (
            result.fixtureId !== deployment.fixtureId &&
            roundOf32DeploymentMatchesResult(deployment, result)
          ) {
            grouped[result.fixtureId] = [
              ...(grouped[result.fixtureId] ?? []),
              deployment,
            ];
          }
        }
      }
    }

    for (const fixtureDeployments of Object.values(grouped)) {
      fixtureDeployments.sort((a, b) => (
        outcomeRank(a.outcomeType) - outcomeRank(b.outcomeType)
      ));
    }

    return grouped;
  }, [finalResults, roundOf32Markets, worldCupDeployments]);

  const startedRoundOf32Markets = useMemo(() => {
    const now = Date.now();

    return roundOf32Markets
      .filter((market) => {
        if (!market.kickoffTime) return false;
        const kickoff = new Date(market.kickoffTime).getTime();
        return !Number.isNaN(kickoff) && kickoff <= now;
      })
      .sort((a, b) => (
        new Date(a.kickoffTime ?? 0).getTime() - new Date(b.kickoffTime ?? 0).getTime()
      ));
  }, [roundOf32Markets]);

  const hiddenNotDeployedCount = finalResults.length - deployedFinalResults.length;
  const settledFixtureCount = deployedFinalResults.filter((result) => (
    resolverStatuses[result.fixtureId]?.status === "settled"
  )).length;
  const readyToSettleCount = visibleFinalResults.filter((result) => (
    resolverStatuses[result.fixtureId]?.status === "readyToSettle"
  )).length;
  const waitingFixtureCount = visibleFinalResults.filter((result) => (
    resolverStatuses[result.fixtureId]?.status === "waiting"
  )).length;
  const fastSettleVisibleCount = visibleFinalResults.filter((result) => (
    resolverStatuses[result.fixtureId]?.fastSettleAvailable === true
  )).length;

  const runResolver = async (
    action: "resolveFixture" | "settleFixture" | "settleReady" | "resolveAndFastSettle",
    fixtureId?: string,
  ) => {
    const key = adminKey.trim();

    if (!key) {
      setResolverError("Paste ADMIN_API_KEY first.");
      return;
    }

    const busyKey = fixtureId ? `${action}:${fixtureId}` : action;
    setResolverBusy(busyKey);
    setResolverError("");

    try {
      const response = await fetch("/api/world-cup/manual-resolve", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-key": key,
        },
        body: JSON.stringify({ action, fixtureId, limit: 12 }),
      });

      const data = (await response.json().catch(() => ({}))) as ResolverResponse;

      if (!response.ok) {
        throw new Error(data.error || "Resolver request failed.");
      }

      setResolverResponse(data);
      window.setTimeout(() => {
        void loadResolverStatuses();
      }, 1_500);
      window.setTimeout(() => {
        void loadResolverStatuses();
      }, 7_000);
    } catch (error) {
      setResolverError(
        error instanceof Error ? error.message : "Resolver request failed.",
      );
    } finally {
      setResolverBusy("");
    }
  };

  const updateResultForm = (
    marketId: string,
    patch: Partial<ResultFormState>,
  ) => {
    const defaultForm: ResultFormState = {
      homeScore: "",
      awayScore: "",
      winningSide: "YES",
      resultSource: "Official match result",
    };

    setResultForms((current) => ({
      ...current,
      [marketId]: {
        ...(current[marketId] ?? defaultForm),
        ...patch,
      },
    }));
  };

  const getResultForm = (market: RoundOf32Market): ResultFormState => (
    resultForms[market.id] ?? {
      homeScore:
        typeof market.finalHomeScore === "number" ? String(market.finalHomeScore) : "",
      awayScore:
        typeof market.finalAwayScore === "number" ? String(market.finalAwayScore) : "",
      winningSide: market.winningSide ?? "YES",
      resultSource: market.resultSource || "Official match result",
      status: "idle",
    }
  );

  const saveRoundOf32Result = async (market: RoundOf32Market) => {
    const key = adminKey.trim();
    const form = getResultForm(market);
    const homeScore = Number(form.homeScore);
    const awayScore = Number(form.awayScore);

    if (!key) {
      updateResultForm(market.id, {
        status: "error",
        message: "Paste ADMIN_API_KEY first.",
      });
      return;
    }

    if (
      !Number.isInteger(homeScore) ||
      !Number.isInteger(awayScore) ||
      homeScore < 0 ||
      awayScore < 0
    ) {
      updateResultForm(market.id, {
        status: "error",
        message: "Enter whole-number scores for both teams.",
      });
      return;
    }

    updateResultForm(market.id, { status: "saving", message: "" });

    try {
      const response = await fetch("/api/world-cup/results", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-key": key,
        },
        body: JSON.stringify({
          fixtureId: market.id,
          marketAddress: market.marketAddress ?? market.address,
          homeScore,
          awayScore,
          status: "final",
          winningSide: form.winningSide,
          resultSource: form.resultSource || "Official match result",
        }),
      });
      const data = (await response.json().catch(() => ({}))) as {
        error?: string;
      };

      if (!response.ok) {
        throw new Error(data.error || "Result save failed.");
      }

      updateResultForm(market.id, {
        status: "success",
        message: "Result saved.",
      });
      await loadRoundOf32Markets();
      await loadWorldCupResults();
      window.setTimeout(() => {
        void loadResolverStatuses();
      }, 1_000);
    } catch (error) {
      updateResultForm(market.id, {
        status: "error",
        message: error instanceof Error ? error.message : "Result save failed.",
      });
    }
  };

  const runVisibleFastSettleBatch = async () => {
    const key = adminKey.trim();

    if (!key) {
      setResolverError("Paste ADMIN_API_KEY first.");
      return;
    }

    const fixturesToProcess = visibleFinalResults.slice(0, 12);

    if (fixturesToProcess.length === 0) {
      setResolverError("No visible fixtures from today onward to resolve.");
      return;
    }

    setResolverBusy("resolveVisibleFastSettle");
    setResolverError("");

    const aggregate: ResolverResponse = {
      success: true,
      action: "resolveVisibleFastSettle",
      scanned: 0,
      proposed: 0,
      timerAdvanced: 0,
      settled: 0,
      skipped: 0,
      failed: 0,
      items: [],
    };

    try {
      for (const result of fixturesToProcess) {
        const response = await fetch("/api/world-cup/manual-resolve", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-admin-key": key,
          },
          body: JSON.stringify({
            action: "resolveAndFastSettle",
            fixtureId: result.fixtureId,
            limit: 12,
          }),
        });

        const data = (await response.json().catch(() => ({}))) as ResolverResponse;

        if (!response.ok) {
          throw new Error(data.error || `Resolver request failed for ${result.fixtureId}.`);
        }

        aggregate.scanned = (aggregate.scanned ?? 0) + (data.scanned ?? 0);
        aggregate.proposed = (aggregate.proposed ?? 0) + (data.proposed ?? 0);
        aggregate.timerAdvanced = (aggregate.timerAdvanced ?? 0) + (data.timerAdvanced ?? 0);
        aggregate.settled = (aggregate.settled ?? 0) + (data.settled ?? 0);
        aggregate.skipped = (aggregate.skipped ?? 0) + (data.skipped ?? 0);
        aggregate.failed = (aggregate.failed ?? 0) + (data.failed ?? 0);
        aggregate.items = [...(aggregate.items ?? []), ...(data.items ?? [])];
      }

      setResolverResponse(aggregate);
      window.setTimeout(() => {
        void loadResolverStatuses();
      }, 1_500);
      window.setTimeout(() => {
        void loadResolverStatuses();
      }, 7_000);
    } catch (error) {
      setResolverError(
        error instanceof Error ? error.message : "Resolver request failed.",
      );
    } finally {
      setResolverBusy("");
    }
  };

  if (!adminMarketCreateEnabled) {
    return (
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-4 px-4 py-5 sm:px-6 lg:px-8">
        <section className="exchange-panel p-6">
          <h1 className="text-xl font-bold text-[#EAECEF]">Admin disabled</h1>
          <p className="mt-2 text-sm text-[#707A8A]">
            Market deployment is hidden unless admin market creation is enabled.
          </p>
        </section>
      </div>
    );
  }

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-5 px-4 py-5 sm:px-6 lg:px-8">
      <section className="exchange-panel overflow-hidden border border-[#FCD535]/20">
        <div className="terminal-titlebar flex items-center justify-between gap-3 px-3 py-2 text-sm font-bold">
          <span>Finished / Started World Cup Fixtures</span>
          <span className="rounded-full border border-[#FCD535]/50 bg-[#FCD535]/10 px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-[#FCD535]">
            Knockout
          </span>
        </div>

        <div className="p-4">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-black text-[#EAECEF]">
                Enter final knockout results
              </h2>
              <p className="mt-1 text-sm leading-6 text-[#707A8A]">
                Save the official score and advancing side before using the UMA resolver.
              </p>
            </div>

            <button
              className="focus-ring rounded-lg border border-[#2B3139] bg-[#0B0E11] px-4 py-2 text-sm font-black text-[#EAECEF] transition hover:border-[#FCD535]"
              onClick={() => {
                void loadRoundOf32Markets();
                void loadWorldCupResults();
                void loadResolverStatuses();
              }}
              type="button"
            >
              Refresh fixtures
            </button>
          </div>

          {!adminKey.trim() ? (
            <p className="mt-3 rounded-lg border border-[#FF8A00]/40 bg-[#FF8A00]/10 px-3 py-2 text-xs font-bold text-[#FF9D2E]">
              Paste and save ADMIN_API_KEY in the Admin deploy key box before saving results or resolving.
            </p>
          ) : null}

          <div className="mt-4 grid gap-3 lg:grid-cols-2">
            {roundOf32Loading ? (
              <div className="rounded-xl border border-[#2B3139] bg-[#0B0E11] p-4 text-sm font-bold text-[#707A8A]">
                Loading started knockout fixtures...
              </div>
            ) : null}

            {!roundOf32Loading && startedRoundOf32Markets.length === 0 ? (
              <div className="rounded-xl border border-[#2B3139] bg-[#0B0E11] p-4 text-sm font-bold text-[#707A8A]">
                No deployed knockout fixtures have reached kickoff yet.
              </div>
            ) : null}

            {startedRoundOf32Markets.map((market) => {
              const form = getResultForm(market);
              const marketAddress = market.marketAddress ?? market.address ?? "";
              const status = resolverStatuses[market.id]?.status ?? "unknown";
              const saved = market.resultStatus === "saved" && !!market.winningSide;
              const saving = form.status === "saving";
              const busyResolve = resolverBusy === `resolveFixture:${market.id}`;
              const busyFastSettle = resolverBusy === `resolveAndFastSettle:${market.id}`;
              const canResolve =
                saved &&
                (
                  status === "needsResolve" ||
                  status === "partial" ||
                  status === "unknown" ||
                  status === "waiting" ||
                  status === "readyToSettle" ||
                  status === "oracleSettled"
                );
              const canSettle = saved && status === "readyToSettle";
              const canFastSettle =
                saved &&
                resolverStatuses[market.id]?.fastSettleAvailable === true &&
                (
                  status === "needsResolve" ||
                  status === "partial" ||
                  status === "unknown" ||
                  status === "waiting" ||
                  status === "readyToSettle"
                );

              return (
                <article
                  className="rounded-xl border border-[#2B3139] bg-[#0B0E11] p-3"
                  key={market.id}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-xs font-black uppercase tracking-[0.14em] text-[#707A8A]">
                        {market.homeTeam} vs {market.awayTeam}
                      </p>
                      <h3 className="mt-1 text-base font-black text-[#EAECEF]">
                        {market.title}
                      </h3>
                      <p className="mt-1 text-xs font-bold text-[#707A8A]">
                        Kickoff {formatDateTime(market.kickoffTime)}
                      </p>
                    </div>

                    <span className={`shrink-0 rounded-full border px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] ${resultStatusClass(market.resultStatus)}`}>
                      {resultStatusLabel(market.resultStatus)}
                    </span>
                  </div>

                  <div className="mt-3 grid gap-2 text-xs">
                    <Meta label="Market" value={marketAddress ? shortAddress(marketAddress) : "Missing"} />
                    <Meta
                      label="Current result"
                      value={
                        saved
                          ? `${market.finalHomeScore ?? "-"}-${market.finalAwayScore ?? "-"} / ${market.winningTeam ?? market.winningSide} advances`
                          : "No result saved"
                      }
                    />
                  </div>

                  <div className="mt-3 grid gap-3 rounded-lg border border-[#1E2329] bg-[#181A20] p-3 sm:grid-cols-2">
                    <label className="text-xs font-bold text-[#AEB4BC]">
                      {market.homeTeam} score
                      <Input
                        className="mt-1"
                        min={0}
                        onChange={(event) => updateResultForm(market.id, { homeScore: event.target.value })}
                        type="number"
                        value={form.homeScore}
                      />
                    </label>

                    <label className="text-xs font-bold text-[#AEB4BC]">
                      {market.awayTeam} score
                      <Input
                        className="mt-1"
                        min={0}
                        onChange={(event) => updateResultForm(market.id, { awayScore: event.target.value })}
                        type="number"
                        value={form.awayScore}
                      />
                    </label>

                    <label className="text-xs font-bold text-[#AEB4BC]">
                      Winning team / advances
                      <select
                        className="focus-ring mt-1 h-10 w-full rounded-lg border border-[#2B3139] bg-[#0B0E11] px-3 text-sm font-bold text-[#EAECEF]"
                        onChange={(event) => updateResultForm(market.id, { winningSide: event.target.value as "YES" | "NO" })}
                        value={form.winningSide}
                      >
                        <option value="YES">{market.homeTeam} = YES</option>
                        <option value="NO">{market.awayTeam} = NO</option>
                      </select>
                    </label>

                    <label className="text-xs font-bold text-[#AEB4BC]">
                      Notes / source
                      <Input
                        className="mt-1"
                        onChange={(event) => updateResultForm(market.id, { resultSource: event.target.value })}
                        value={form.resultSource}
                      />
                    </label>
                  </div>

                  {form.message ? (
                    <p className={`mt-3 rounded-lg border px-3 py-2 text-xs font-bold ${
                      form.status === "error"
                        ? "border-[#F6465D]/40 bg-[#F6465D]/10 text-[#FFD7DD]"
                        : "border-[#0ECB81]/40 bg-[#0ECB81]/10 text-[#BFFFE7]"
                    }`}>
                      {form.message}
                    </p>
                  ) : null}

                  <div className="mt-3 rounded-lg border border-[#1E2329] bg-[#06080A] px-3 py-2 text-xs leading-5 text-[#AEB4BC]">
                    <span className="font-black uppercase tracking-[0.12em] text-[#FCD535]">
                      {saved ? statusLabel(status) : "No result saved"}
                    </span>
                    <span className="ml-2">
                      {saved
                        ? resolverStatuses[market.id]?.reason ?? "Save refreshes status; resolve is gated by result metadata."
                        : "Resolve stays disabled until an admin-saved result exists."}
                    </span>
                  </div>

                  <div className="mt-3 flex flex-wrap gap-2">
                    <button
                      className="terminal-button focus-ring px-3 py-2 text-sm font-black disabled:cursor-not-allowed disabled:opacity-50"
                      disabled={saving || !adminKey.trim()}
                      onClick={() => void saveRoundOf32Result(market)}
                      type="button"
                    >
                      {saving ? "Saving..." : "Save Result"}
                    </button>

                    <button
                      className="terminal-button focus-ring px-3 py-2 text-sm font-black disabled:cursor-not-allowed disabled:opacity-50"
                      disabled={!canResolve || !adminKey.trim() || !!resolverBusy}
                      onClick={() => void runResolver("resolveFixture", market.id)}
                      type="button"
                    >
                      {busyResolve ? "Proposing..." : "Propose Result"}
                    </button>

                    <button
                      className="terminal-button focus-ring px-3 py-2 text-sm font-black disabled:cursor-not-allowed disabled:opacity-50"
                      disabled={!canFastSettle || !adminKey.trim() || !!resolverBusy}
                      onClick={() => void runResolver("resolveAndFastSettle", market.id)}
                      type="button"
                    >
                      {busyFastSettle ? "Resolving & settling..." : "Resolve & Fast Settle"}
                    </button>

                    {canSettle ? (
                      <button
                        className="terminal-button focus-ring px-3 py-2 text-sm font-black disabled:cursor-not-allowed disabled:opacity-50"
                        disabled={!adminKey.trim() || !!resolverBusy}
                        onClick={() => void runResolver("settleFixture", market.id)}
                        type="button"
                      >
                        Settle Fixture
                      </button>
                    ) : null}
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="exchange-panel overflow-hidden border border-[#FF8A00]/20">
        <div className="terminal-titlebar flex items-center justify-between gap-3 px-3 py-2 text-sm font-bold">
          <span>World Cup Results & Resolver</span>
          <span className="rounded-full border border-[#0ECB81]/50 bg-[#0ECB81]/10 px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-[#BFFFE7]">
            Manual safe mode
          </span>
        </div>

        <div className="grid gap-4 p-4 xl:grid-cols-[1fr_380px]">
          <div>
            <div className="flex items-start gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#FF8A00] text-[#181A20]">
                <Trophy className="h-5 w-5" />
              </div>

              <div>
                <h2 className="text-2xl font-black text-[#EAECEF]">
                  Resolve finished fixtures
                </h2>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-[#707A8A]">
                  Resolve and settle visible finished fixtures only. Past fixtures before today are hidden
                  from this admin queue so you can focus on current matches.
                </p>
                <p className="mt-2 text-xs font-bold text-[#FF9D2E]">
                  Testnet admin shortcut. Public settlement still uses UMA liveness.
                </p>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <button
                className="focus-ring rounded-lg border border-[#2B3139] bg-[#0B0E11] px-4 py-2 text-sm font-black text-[#EAECEF] transition hover:border-[#FF8A00]"
                onClick={() => {
                  void loadWorldCupResults();
                  void loadWorldCupDeployments();
                  void loadRoundOf32Markets();
                  void loadResolverStatuses();
                }}
                type="button"
              >
                Refresh status
              </button>

              <button
                className="terminal-button focus-ring px-4 py-2 text-sm font-black disabled:cursor-not-allowed disabled:opacity-50"
                disabled={
                  !adminKey.trim() ||
                  !!resolverBusy ||
                  visibleFinalResults.length === 0 ||
                  fastSettleVisibleCount === 0
                }
                onClick={() => void runVisibleFastSettleBatch()}
                type="button"
              >
                {resolverBusy === "resolveVisibleFastSettle"
                  ? "Resolving visible fixtures..."
                  : fastSettleVisibleCount > 0
                    ? "Resolve & Fast Settle Visible"
                    : "Visible Fixtures Waiting Liveness"}
              </button>

              {readyToSettleCount > 0 ? (
                <button
                  className="terminal-button focus-ring px-4 py-2 text-sm font-black disabled:cursor-not-allowed disabled:opacity-50"
                  disabled={!adminKey.trim() || !!resolverBusy}
                  onClick={() => void runResolver("settleReady")}
                  type="button"
                >
                  {resolverBusy === "settleReady"
                    ? "Settling..."
                    : `Settle ${readyToSettleCount} ready fixture${readyToSettleCount > 1 ? "s" : ""}`}
                </button>
              ) : null}

              {waitingFixtureCount > 0 ? (
                <span className="rounded-lg border border-[#FF8A00]/30 bg-[#FF8A00]/10 px-3 py-2 text-xs font-bold text-[#FF9D2E]">
                  {waitingFixtureCount} fixture{waitingFixtureCount > 1 ? "s" : ""} waiting liveness
                </span>
              ) : null}

              {hiddenPastFixtureCount > 0 ? (
                <span className="rounded-lg border border-[#2B3139] bg-[#1E2329] px-3 py-2 text-xs font-bold text-[#707A8A]">
                  {hiddenPastFixtureCount} past fixture{hiddenPastFixtureCount > 1 ? "s" : ""} before today hidden
                </span>
              ) : null}

              {settledFixtureCount > 0 ? (
                <span className="rounded-lg border border-[#0ECB81]/30 bg-[#0ECB81]/10 px-3 py-2 text-xs font-bold text-[#BFFFE7]">
                  {settledFixtureCount} settled hidden
                </span>
              ) : null}

              {hiddenNotDeployedCount > 0 ? (
                <span className="rounded-lg border border-[#2B3139] bg-[#1E2329] px-3 py-2 text-xs font-bold text-[#707A8A]">
                  {hiddenNotDeployedCount} not deployed hidden
                </span>
              ) : null}
            </div>

            {!adminKey.trim() ? (
              <p className="mt-3 rounded-lg border border-[#FF8A00]/40 bg-[#FF8A00]/10 px-3 py-2 text-xs font-bold text-[#FF9D2E]">
                Paste and save ADMIN_API_KEY above before resolving.
              </p>
            ) : null}

            {resolverError ? (
              <p className="mt-3 rounded-lg border border-[#F6465D]/40 bg-[#F6465D]/10 px-3 py-2 text-xs font-bold text-[#FFD7DD]">
                {resolverError}
              </p>
            ) : null}

            <div className="mt-4 grid gap-3 lg:grid-cols-2">
              {resultsLoading ? (
                <div className="rounded-xl border border-[#2B3139] bg-[#0B0E11] p-4 text-sm font-bold text-[#707A8A]">
                  Loading World Cup results...
                </div>
              ) : null}

              {!resultsLoading && visibleFinalResults.length === 0 ? (
                <div className="rounded-xl border border-[#2B3139] bg-[#0B0E11] p-4 text-sm font-bold text-[#707A8A]">
                  No unresolved deployed final fixtures from today onward. Past, settled, and undeployed fixtures are hidden.
                </div>
              ) : null}

              {visibleFinalResults.map((result) => {
                const busyResolve = resolverBusy === `resolveFixture:${result.fixtureId}`;
                const busySettle = resolverBusy === `settleFixture:${result.fixtureId}`;
                const busyFastSettle = resolverBusy === `resolveAndFastSettle:${result.fixtureId}`;
                const status = resolverStatuses[result.fixtureId];
                const statusKey = status?.status ?? "unknown";
                const fixtureDeployments = deploymentsByFixture[result.fixtureId] ?? [];
                const deployedCount = fixtureDeployments.length;
                const isRoundOf32Result = fixtureDeployments.some((deployment) => deployment.isRoundOf32V2);
                const expectedDeploymentCount = isRoundOf32Result ? 1 : 3;
                const fastSettleAvailable = status?.fastSettleAvailable === true;
                const canResolve =
                  statusKey === "needsResolve" ||
                  statusKey === "partial" ||
                  statusKey === "unknown";
                const canSettle = statusKey === "readyToSettle";

                return (
                  <article
                    className="rounded-xl border border-[#2B3139] bg-[#0B0E11] p-3"
                    key={result.fixtureId}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-xs font-black uppercase tracking-[0.14em] text-[#707A8A]">
                          {result.fixtureId}
                        </p>
                        <h3 className="mt-1 text-lg font-black text-[#EAECEF]">
                          {result.homeTeam} {result.homeScore ?? "-"} - {result.awayScore ?? "-"} {result.awayTeam}
                        </h3>
                      </div>

                      <span className="rounded-full border border-[#0ECB81]/40 bg-[#0ECB81]/10 px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-[#BFFFE7]">
                        {result.result?.replace("_", " ")}
                      </span>
                    </div>

                    <div className="mt-3 rounded-lg border border-[#1E2329] bg-[#181A20] px-3 py-2 text-xs leading-5 text-[#AEB4BC]">
                      <span className="font-black uppercase tracking-[0.12em] text-[#FF8A00]">
                        {statusLabel(statusKey)}
                      </span>
                      <span className="ml-2">
                        {statusesLoading ? "Loading status..." : status?.reason ?? "Status not loaded yet."}
                      </span>
                    </div>

                    <div className="mt-3 rounded-lg border border-[#1E2329] bg-[#06080A] p-3">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#707A8A]">
                          {isRoundOf32Result ? "Deployed V2 market" : "Deployed V2 markets"}
                        </p>
                        <span className="font-mono text-[11px] font-black text-[#FF8A00]">
                          {deploymentsLoading ? "..." : `${deployedCount}/${expectedDeploymentCount}`}
                        </span>
                      </div>

                      {deploymentsLoading ? (
                        <p className="mt-2 text-xs font-bold text-[#707A8A]">
                          Loading deployed markets...
                        </p>
                      ) : fixtureDeployments.length === 0 ? (
                        <p className="mt-2 text-xs font-bold text-[#707A8A]">
                          No deployed V2 {isRoundOf32Result ? "market" : "markets"} indexed for this finished fixture.
                        </p>
                      ) : (
                        <div className="mt-2 grid gap-2">
                          {fixtureDeployments.map((deployment) => {
                            const proposedSide = suggestedSideFor(result, deployment);

                            return (
                              <Link
                                className="focus-ring flex items-center justify-between gap-3 rounded-lg border border-[#2B3139] bg-[#181A20] px-3 py-2 text-xs transition hover:border-[#FF8A00]/70"
                                href={`/market/${deployment.marketAddress}?tab=resolve`}
                                key={`${deployment.fixtureId}-${deployment.outcomeType}-${deployment.marketAddress}`}
                              >
                                <span className="min-w-0">
                                  <span className="block font-black text-[#EAECEF]">
                                    {outcomeLabel(deployment.outcomeType)}
                                  </span>
                                  <span className="mt-0.5 block truncate text-[#707A8A]">
                                    {deployment.question}
                                  </span>
                                </span>

                                <span className="flex shrink-0 items-center gap-2">
                                  <span className={`rounded-full border px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] ${proposedSideClass(proposedSide)}`}>
                                    Propose {proposedSide}
                                  </span>
                                  <span className="interactive-link text-[11px]">
                                    Resolve
                                  </span>
                                </span>
                              </Link>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      <button
                        className="terminal-button focus-ring px-3 py-2 text-sm font-black disabled:cursor-not-allowed disabled:opacity-50"
                        disabled={!adminKey.trim() || !!resolverBusy || !fastSettleAvailable}
                        onClick={() => void runResolver("resolveAndFastSettle", result.fixtureId)}
                        type="button"
                      >
                        {busyFastSettle
                          ? "Resolving & settling..."
                          : fastSettleAvailable
                            ? "Resolve & Fast Settle"
                            : "Propose / Check Liveness"}
                      </button>

                      {canResolve ? (
                        <button
                          className="terminal-button focus-ring px-3 py-2 text-sm font-black disabled:cursor-not-allowed disabled:opacity-50"
                          disabled={!adminKey.trim() || !!resolverBusy}
                          onClick={() => void runResolver("resolveFixture", result.fixtureId)}
                          type="button"
                        >
                          {busyResolve ? "Resolving..." : "Resolve Fixture"}
                        </button>
                      ) : null}

                      {canSettle ? (
                        <button
                          className="terminal-button focus-ring px-3 py-2 text-sm font-black disabled:cursor-not-allowed disabled:opacity-50"
                          disabled={!adminKey.trim() || !!resolverBusy}
                          onClick={() => void runResolver("settleFixture", result.fixtureId)}
                          type="button"
                        >
                          {busySettle ? "Settling..." : "Settle Fixture"}
                        </button>
                      ) : null}

                      {statusKey === "waiting" ? (
                        <button
                          className="rounded-lg border border-[#2B3139] bg-[#1E2329] px-3 py-2 text-sm font-black text-[#707A8A]"
                          disabled
                          type="button"
                        >
                          {fastSettleAvailable ? "Fast settle available" : "Waiting liveness"}
                        </button>
                      ) : null}

                      {statusKey === "oracleSettled" ? (
                        <button
                          className="rounded-lg border border-[#F6465D]/40 bg-[#F6465D]/10 px-3 py-2 text-sm font-black text-[#FFD7DD]"
                          disabled
                          type="button"
                        >
                          Oracle settled, market not updated
                        </button>
                      ) : null}

                      {statusKey === "notDeployed" ? (
                        <button
                          className="rounded-lg border border-[#2B3139] bg-[#1E2329] px-3 py-2 text-sm font-black text-[#707A8A]"
                          disabled
                          type="button"
                        >
                          Not deployed
                        </button>
                      ) : null}
                    </div>
                  </article>
                );
              })}
            </div>
          </div>

          <div className="rounded-xl border border-[#2B3139] bg-[#0B0E11] p-3">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-[#707A8A]">
              Latest resolver run
            </p>

            {resolverResponse ? (
              <>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-3">
                  <ResolveMetric label="Scanned" value={resolverResponse.scanned ?? 0} />
                  <ResolveMetric label="Proposed" value={resolverResponse.proposed ?? 0} />
                  <ResolveMetric label="Timer advanced" value={resolverResponse.timerAdvanced ?? 0} />
                  <ResolveMetric label="Settled" value={resolverResponse.settled ?? 0} />
                  <ResolveMetric label="Skipped" value={resolverResponse.skipped ?? 0} />
                  <ResolveMetric label="Failed" value={resolverResponse.failed ?? 0} />
                </div>

                <div className="mt-3 max-h-80 overflow-y-auto rounded-lg border border-[#2B3139] bg-[#06080A]">
                  {resolverResponse.items?.map((item, index) => (
                    <div
                      className="border-b border-[#1E2329] px-3 py-2 text-xs last:border-b-0"
                      key={`${item.fixtureId}-${item.outcomeType}-${index}`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-[#EAECEF]">
                          {item.outcomeType}
                          {item.proposedSide ? ` → ${item.proposedSide}` : ""}
                        </span>
                        <span className="font-mono text-[#FF8A00]">{item.action}</span>
                      </div>
                      <p className="mt-1 text-[#707A8A]">{item.reason}</p>
                      {item.txHash ? (
                        <p className="mt-1 break-all font-mono text-[#0ECB81]">{item.txHash}</p>
                      ) : null}
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p className="mt-3 text-sm leading-6 text-[#707A8A]">
                Use Resolve & Fast Settle for one fixture, or process only visible fixtures from today onward.
              </p>
            )}
          </div>
        </div>
      </section>

      <section className="exchange-panel overflow-hidden">
        <div className="terminal-titlebar flex items-center justify-between gap-3 px-3 py-2 text-sm font-bold">
          <span>Admin Market Catalog</span>
          <span className="rounded-full border border-[#FF8A00]/50 bg-[#FF8A00]/10 px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-[#FF8A00]">
            Protected deploy
          </span>
        </div>

        <div className="grid gap-4 p-4 lg:grid-cols-[1fr_380px]">
          <div>
            <h1 className="text-2xl font-black text-[#EAECEF]">
              Deploy real Arc Testnet markets
            </h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-[#707A8A]">
              Templates stay hidden from public Home until deployed. Each card calls the protected
              V2 server deployer, creates a real USDC market, initializes UMA settlement, deploys an AMM,
              and seeds native USDC liquidity on Arc Testnet.
            </p>

            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <AdminMetric
                icon={<Layers3 className="h-4 w-4" />}
                label="Templates"
                value={String(MARKET_TEMPLATES.length)}
              />
              <AdminMetric
                icon={<ShieldCheck className="h-4 w-4" />}
                label="Server guard"
                value="Required"
              />
              <AdminMetric
                icon={<KeyRound className="h-4 w-4" />}
                label="Admin key"
                value={adminKey.trim() ? "Ready" : "Missing"}
              />
            </div>
          </div>

          <div className="rounded-xl border border-[#2B3139] bg-[#0B0E11] p-3">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#FF8A00] text-[#181A20]">
                <KeyRound className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-black text-[#EAECEF]">Admin deploy key</p>
                <p className="mt-1 text-xs leading-5 text-[#707A8A]">
                  Must match server <span className="font-mono text-[#EAECEF]">ADMIN_API_KEY</span>.
                  Stored locally in this browser only.
                </p>
              </div>
            </div>

            <div className="mt-3 flex gap-2">
              <Input
                aria-label="Admin API key"
                className="font-mono"
                onChange={(event) => setAdminKey(event.target.value)}
                placeholder="Paste ADMIN_API_KEY"
                type="password"
                value={adminKey}
              />
              <button
                className="terminal-button focus-ring shrink-0 px-3 py-2 text-sm font-black"
                onClick={saveAdminKey}
                type="button"
              >
                {saved ? "Saved" : "Save"}
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-[#2B3139] p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="relative w-full lg:max-w-md">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#707A8A]" />
              <Input
                aria-label="Search templates"
                className="pl-9"
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search market templates"
                value={query}
              />
            </div>

            <div className="flex gap-1.5 overflow-x-auto pb-1 lg:pb-0">
              {categories.map((category) => (
                <button
                  className={
                    activeCategory === category
                      ? "focus-ring market-chip-active shrink-0 px-3 py-1.5 text-xs font-bold"
                      : "focus-ring market-chip shrink-0 px-3 py-1.5 text-xs font-bold transition hover:border-[#FF8A00] hover:text-[#EAECEF]"
                  }
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  type="button"
                >
                  {category}
                  {category !== "All" ? (
                    <span className="ml-1 text-[#707A8A]">
                      {categoryCounts[category]}
                    </span>
                  ) : (
                    <span className="ml-1 text-[#707A8A]">{MARKET_TEMPLATES.length}</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {visibleTemplates.map((template) => {
          const copy = categoryCopy[template.category as AdminCatalogCategory];
          const deployState = templateDeployStates[template.id] ?? { status: "idle" };
          const deploying = deployState.status === "deploying";
          const alreadyDeployed =
            deployedTemplateIds.has(template.worldCupMarketId ?? template.id) ||
            deployState.status === "success";
          const disabledReason =
            template.deployDisabledReason ??
            (!template.kickoffTime && template.category === "World Cup" && template.stage === "Round of 16"
              ? "Exact kickoffTime is not configured yet."
              : "");
          const deployDisabled = deploying || alreadyDeployed || template.deployDisabled === true || Boolean(disabledReason);

          return (
            <article
              className="group flex min-h-[320px] flex-col justify-between rounded-xl border border-[#2B3139] bg-[#1E2329] p-4 transition hover:-translate-y-0.5 hover:border-[#FF8A00]/70 hover:shadow-[0_14px_40px_rgba(255,138,0,0.08)]"
              key={template.id}
            >
              <div>
                <div className="mb-4 flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-[#3A424D] bg-[#0B0E11] font-mono text-sm font-black text-[#FF8A00]">
                      {copy.icon}
                    </div>
                    <div>
                      <p className="text-xs font-black uppercase tracking-[0.14em] text-[#707A8A]">
                        {copy.label}
                      </p>
                      <p className="mt-0.5 line-clamp-1 text-xs text-[#707A8A]">
                        {copy.description}
                      </p>
                    </div>
                  </div>

                  <span className={`rounded-full border px-2 py-1 text-[11px] font-black ${riskClass(template.riskLevel)}`}>
                    {template.riskLevel}
                  </span>
                </div>

                <h2 className="text-base font-black leading-snug text-[#EAECEF]">
                  {template.title}
                </h2>

                <div className="mt-4 grid gap-2 text-xs">
                  <Meta label="Source" value={template.source} />
                  <Meta label="End date" value={template.endDate} />
                </div>

                <div className="mt-3 rounded-xl border border-[#2B3139] bg-[#0B0E11] p-3">
                  <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#707A8A]">
                    Settlement rule
                  </p>
                  <p className="mt-1 text-xs leading-5 text-[#AEB4BC]">
                    {template.settlementRule}
                  </p>
                </div>
              </div>

              <div className="mt-4">
                <button
                  className="terminal-button focus-ring w-full px-3 py-2 text-sm font-bold disabled:cursor-not-allowed disabled:opacity-60"
                  disabled={deployDisabled}
                  onClick={() => void deployTemplate(template)}
                  type="button"
                >
                  {deploying ? "Deploying…" : alreadyDeployed ? "Deployed" : disabledReason ? "Needs kickoff time" : "Deploy on Arc"}
                </button>

                {disabledReason && !alreadyDeployed ? (
                  <p className="mt-3 rounded-lg border border-[#FF8A00]/40 bg-[#FF8A00]/10 px-3 py-2 text-xs font-bold text-[#FF9D2E]">
                    {disabledReason}
                  </p>
                ) : null}

                {deployState.status === "success" ? (
                  <div className="mt-3 rounded-lg border border-[#0ECB81]/40 bg-[#0ECB81]/10 p-3 text-xs">
                    <p className="font-black text-[#BFFFE7]">
                      V{deployState.contractVersion ?? 2} {deployState.collateralSymbol ?? "USDC"}
                      {deployState.collateralDecimals ? ` / ${deployState.collateralDecimals} decimals` : ""} market deployed
                    </p>
                    <p className="mt-1 font-mono text-[#EAECEF]">
                      {shortAddress(deployState.marketAddress)}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-3">
                      <Link
                        className="interactive-link font-bold"
                        href={`/market/${deployState.marketAddress}`}
                      >
                        Open market
                      </Link>
                      {deployState.transactionHash ? (
                      <a
                        className="interactive-link font-bold"
                        href={arcTxUrl(deployState.transactionHash)}
                        rel="noreferrer"
                        target="_blank"
                      >
                        View tx
                      </a>
                      ) : null}
                    </div>
                  </div>
                ) : null}

                {deployState.status === "error" ? (
                  <p className="mt-3 rounded-lg border border-[#F6465D]/40 bg-[#F6465D]/10 px-3 py-2 text-xs font-bold text-[#FFD7DD]">
                    {deployState.message}
                  </p>
                ) : null}
              </div>
            </article>
          );
        })}
      </section>

      {visibleTemplates.length === 0 ? (
        <section className="exchange-panel p-6 text-center">
          <p className="font-bold text-[#EAECEF]">No templates found.</p>
          <p className="mt-1 text-sm text-[#707A8A]">
            Try another category or search term.
          </p>
        </section>
      ) : null}
    </div>
  );
}


function getLocalDateKey(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function stablePairName(templateId: string) {
  const slug = templateId
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 58);

  return `ARCM-${slug || "template"}`;
}

function getTemplateWorldCupMarketId(template: MarketTemplate) {
  if (
    "worldCupMarketId" in template &&
    typeof template.worldCupMarketId === "string"
  ) {
    return template.worldCupMarketId.trim();
  }

  return "";
}

function normalizeMatchText(value?: string | null) {
  return (value ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function isSupportedKnockoutStage(stage?: string | null) {
  const normalized = normalizeMatchText(stage);
  return normalized === "round of 32" || normalized === "round of 16";
}

function isRoundOf32Market(market: RoundOf32Market) {
  return (
    market.category === "World Cup" &&
    isSupportedKnockoutStage(market.stage) &&
    market.contractVersion === 2 &&
    Boolean(market.marketAddress || market.address) &&
    Boolean(market.ammAddress)
  );
}

function roundOf32Title(homeTeam?: string, awayTeam?: string) {
  return knockoutTitle(homeTeam, awayTeam, "Round of 32");
}

function knockoutTitle(homeTeam?: string, awayTeam?: string, stage = "Round of 32") {
  if (!homeTeam || !awayTeam) return "";
  return `Will ${homeTeam} eliminate ${awayTeam} in the ${stage}?`;
}

function roundOf32DeploymentMatchesResult(
  deployment: WorldCupDeployment,
  result: WorldCupResultRecord,
) {
  if (!deployment.isRoundOf32V2) return false;

  const normalizedQuestion = normalizeMatchText(deployment.question);
  const exactTitles = ["Round of 32", "Round of 16"].map((stage) =>
    normalizeMatchText(knockoutTitle(result.homeTeam, result.awayTeam, stage)),
  );
  if (exactTitles.some((title) => title && normalizedQuestion === title)) return true;

  const homeTeam = normalizeMatchText(result.homeTeam);
  const awayTeam = normalizeMatchText(result.awayTeam);
  const questionWithStage = normalizeMatchText(`${deployment.question} ${deployment.group ?? ""}`);
  if (!homeTeam || !awayTeam) return false;

  return (
    (questionWithStage.includes("round of 32") || questionWithStage.includes("round of 16")) &&
    questionWithStage.includes(homeTeam) &&
    questionWithStage.includes(awayTeam)
  );
}

function shortAddress(address: string) {
  return address.length > 12
    ? `${address.slice(0, 6)}...${address.slice(-4)}`
    : address;
}

function arcTxUrl(transactionHash: string) {
  return `https://testnet.arcscan.app/tx/${transactionHash}`;
}

function parseDateKey(value?: string | null) {
  if (!value) return null;

  const parsed = new Date(value);

  if (Number.isNaN(parsed.getTime())) return null;

  return getLocalDateKey(parsed);
}

function getFixtureDateKey(result: WorldCupResultRecord) {
  return (
    parseDateKey(result.kickoffTime) ??
    parseDateKey(result.startsAt) ??
    parseDateKey(result.startTime) ??
    parseDateKey(result.scheduledAt) ??
    parseDateKey(result.updateAllowedAt) ??
    WORLD_CUP_FIXTURE_DATE_BY_ID[result.fixtureId] ??
    null
  );
}

function isFixtureOnOrAfterDate(result: WorldCupResultRecord, dateKey: string) {
  const fixtureDateKey = getFixtureDateKey(result);

  if (!fixtureDateKey) return true;

  return fixtureDateKey >= dateKey;
}

function outcomeRank(outcomeType: string) {
  if (outcomeType === "home_win") return 0;
  if (outcomeType === "draw") return 1;
  if (outcomeType === "away_win") return 2;

  return 99;
}

function outcomeLabel(outcomeType: string) {
  if (outcomeType === "home_win") return "Home win";
  if (outcomeType === "draw") return "Draw";
  if (outcomeType === "away_win") return "Away win";

  return outcomeType.replaceAll("_", " ");
}

function suggestedSideFor(
  result: WorldCupResultRecord,
  deployment: WorldCupDeployment,
): "YES" | "NO" {
  return deployment.outcomeType === result.result ? "YES" : "NO";
}

function proposedSideClass(side: "YES" | "NO") {
  return side === "YES"
    ? "border-[#0ECB81]/40 bg-[#0ECB81]/10 text-[#BFFFE7]"
    : "border-[#F6465D]/40 bg-[#F6465D]/10 text-[#FFD7DD]";
}

function statusLabel(status: FixtureResolverStatus["status"] | "unknown") {
  switch (status) {
    case "needsResolve":
      return "Needs resolve";
    case "waiting":
      return "Waiting settle";
    case "readyToSettle":
      return "Ready to settle";
    case "settled":
      return "Settled";
    case "partial":
      return "Partial";
    case "oracleSettled":
      return "Oracle settled";
    case "notDeployed":
      return "Not deployed";
    default:
      return "Unknown";
  }
}

function resultStatusLabel(status?: RoundOf32Market["resultStatus"]) {
  if (status === "saved") return "Result saved";
  if (status === "proposed") return "Proposed";
  if (status === "settled") return "Settled";

  return "No result saved";
}

function resultStatusClass(status?: RoundOf32Market["resultStatus"]) {
  if (status === "saved") {
    return "border-[#0ECB81]/40 bg-[#0ECB81]/10 text-[#BFFFE7]";
  }

  if (status === "proposed") {
    return "border-[#FF8A00]/40 bg-[#FF8A00]/10 text-[#FF9D2E]";
  }

  if (status === "settled") {
    return "border-[#FCD535]/40 bg-[#FCD535]/10 text-[#FCD535]";
  }

  return "border-[#2B3139] bg-[#1E2329] text-[#707A8A]";
}

function formatDateTime(value?: string) {
  if (!value) return "Unknown";

  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;

  return parsed.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function ResolveMetric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg border border-[#2B3139] bg-[#1E2329] p-2">
      <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#707A8A]">
        {label}
      </p>
      <p className="mt-1 font-mono text-lg font-black text-[#FF8A00]">{value}</p>
    </div>
  );
}

function AdminMetric({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-[#2B3139] bg-[#0B0E11] p-3">
      <div className="flex items-center gap-2 text-[#FF8A00]">
        {icon}
        <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#707A8A]">
          {label}
        </p>
      </div>
      <p className="mt-2 font-mono text-lg font-black text-[#EAECEF]">{value}</p>
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-[#2B3139] bg-[#0B0E11] px-3 py-2">
      <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#707A8A]">
        {label}
      </p>
      <p className="mt-1 line-clamp-2 text-xs font-bold text-[#EAECEF]">{value}</p>
    </div>
  );
}

function riskClass(riskLevel: string) {
  if (riskLevel === "Low") {
    return "border-[#0ECB81]/40 bg-[#0ECB81]/10 text-[#BFFFE7]";
  }

  if (riskLevel === "High") {
    return "border-[#F6465D]/40 bg-[#F6465D]/10 text-[#FFD7DD]";
  }

  return "border-[#FF8A00]/40 bg-[#FF8A00]/10 text-[#FF9D2E]";
}
